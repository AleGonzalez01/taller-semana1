class Normal extends Enemigo{
    constructor(x,y){
   super(xe,ye,tame)
   this.xe=x;
   this.ye=y;

    }
}




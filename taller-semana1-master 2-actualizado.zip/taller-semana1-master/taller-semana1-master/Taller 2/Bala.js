let X, Y, Tam;
class Bala{
 constructor(X,Y, Tam){
this.Y=X;
this.X=Y;
this.Tam=Tam;
 }
 
}